﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet01
{
    public partial class marqueVetementsForm : Form
    {
        public marqueVetementsForm()
        {
            InitializeComponent();
            InitialiserFormulaire();

        }

        #region Méthode d’initialisation

        private void InitialiserFormulaire()
        {
            try
            {

                policeToolStripComboBox.Items.Clear();

                var polices = FontFamily.Families
                    .Select(p => p.Name)
                    .OrderByDescending(p => p)
                    .ToList();

                foreach (string nomPolice in polices)
                {
                    policeToolStripComboBox.Items.Add(nomPolice);
                }

                if (policeToolStripComboBox.Items.Count > 0)
                    policeToolStripComboBox.SelectedIndex = 0;

               
                AdapterPoliceRichTextBox();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l’initialisation du formulaire : " + ex.Message,
                                "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion
        private void policeToolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            AdapterPoliceRichTextBox();
        }
        private void AdapterPoliceRichTextBox()
        {
            try
            {
                if (policeToolStripComboBox.SelectedItem != null)
                {
                    string policeChoisie = policeToolStripComboBox.SelectedItem.ToString();
                    vetementRichTextBox.Font = new Font(policeChoisie, 12, FontStyle.Regular);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l’application de la police : " + ex.Message,
                                "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void marqueVetementsForm_Load(object sender, EventArgs e)
        {

        }

        private void imprimerButton_Click(object sender, EventArgs e)
        {
            try
            {
                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.WindowState = FormWindowState.Maximized;
                printPreviewDialog1.PrintPreviewControl.Zoom = 2.0;
                printPreviewDialog1.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l’aperçu avant impression : " + ex.Message,
                                "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            try
            {
                Graphics g = e.Graphics;
                float margeGauche = e.MarginBounds.Left;
                float margeHaut = e.MarginBounds.Top;
                float largeurPage = e.MarginBounds.Width;

                //  Logo centré
                Image logo = Image.FromFile("Data/marques.png"); 
                int largeurLogo = 100;
                int hauteurLogo = 100;
                float positionXLogo = margeGauche + (largeurPage - largeurLogo) / 2;
                g.DrawImage(logo, positionXLogo, margeHaut, largeurLogo, hauteurLogo);

                margeHaut += hauteurLogo + 20;

                //Titre centre
                string titre = "Liste des Marques de Vêtements";
                Font policeTitre = new Font("Arial", 18, FontStyle.Underline);
                SizeF tailleTitre = g.MeasureString(titre, policeTitre);
                float positionXTitre = margeGauche + (largeurPage - tailleTitre.Width) / 2;
                g.DrawString(titre, policeTitre, Brushes.DarkBlue, positionXTitre, margeHaut);
                margeHaut += tailleTitre.Height + 30;

                
                Font policeEntete = new Font("Calibri", 12, FontStyle.Bold);
                Brush brosseEntete = Brushes.DarkRed;
                g.DrawString("Marque", policeEntete, brosseEntete, margeGauche, margeHaut);
                g.DrawString("Taille", policeEntete, brosseEntete, margeGauche + 300, margeHaut);
                margeHaut += 25;

                
                g.DrawLine(Pens.Black, margeGauche, margeHaut, margeGauche + largeurPage, margeHaut);
                margeHaut += 10;

                
                Font policeContenu = new Font("Times New Roman", 11, FontStyle.Regular);
                Brush brosseContenu = Brushes.Black;

                string contenu = vetementRichTextBox.Text;
                string[] lignes = contenu.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string ligne in lignes)
                {
                    g.DrawString(ligne, policeContenu, brosseContenu, margeGauche, margeHaut);
                    margeHaut += 20;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l’impression : " + ex.Message,
                                "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
